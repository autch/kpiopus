== Opusfile ==

Library for decoding .opus files, including seeking support.

Compiled for win32 with the mingw64 toolchain. Built with

  libogg 1.3.1
  libopus 1.1
  openssl 1.0.1f

Programming documentation is available in opusfile-0.5.pdf
included with this package and online at
http://opus-codec.org/docs/opusfile_api-0.5/

= Changes in v0.5 =

 - Report HTTP (ICY) headers to client
 - New tag comparison and copy functions
 - New application decoding callback API for advanced clients
 - New dither disable function for advanced clients
 - constify API

 - Avoid clipping downmixing from a fixed-point decoder
 - Better practices for dual stack IPv6
 - Documentation improvements
 - Fix a unicode bug on Windows
 - Fix proxy user/password macros
 - Fix HTTP pipelining support detection

The library is functional, but there are likely issues
we didn't find in our own testing. Please give feedback
in #opus on irc.freenode.net or at opus@xiph.org.
